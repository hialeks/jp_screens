import 'package:flutter/material.dart';

class Screen02t extends StatelessWidget {
  const Screen02t({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: 855,
        width: 395,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/backgrounds/bg_mainscreen.png"),
            fit: BoxFit.fill,
          ),
        ),
        child: Stack(
          children: [
            const Positioned(
              left: 23,
              top: 514,
              child: Text(
                'We Recommend',
                style: TextStyle(
                  color: Color(0xFFF7F7F7),
                  fontSize: 16,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Positioned(
              left: 23,
              top: 557,
              child: SizedBox(
                height: 262,
                width: 395, // Set the width of the container
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildItem(
                        imageUrl: "assets/grafiken/cat cupcakes_3D.png",
                        cupName: "Mogli’s Cup",
                        productName: "Strawberry ice cream",
                        likes: "♡ 200",
                        price: "₳ 8.99",
                      ),
                      _buildItem(
                        imageUrl: "assets/grafiken/Icecream.png",
                        cupName: "Balus Cup",
                        productName: "Pistachio ice cream",
                        price: "₳ 8.99",
                        likes: "♡ 177",
                      ),
                      _buildItem(
                        imageUrl: "assets/grafiken/Icecream_3D.png",
                        cupName: "Alekss Lolly",
                        productName: "Pistachio ice cream",
                        price: "₳ 8.99",
                        likes: "♡ 317",
                      ),
                      _buildItem(
                        imageUrl: "assets/grafiken/ice cream stick_3D.png",
                        cupName: "Kidss Wonder",
                        productName: "Pistachio ice cream",
                        price: "₳ 8.99",
                        likes: "♡ 177",
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildItem({
    required String imageUrl,
    required String cupName,
    required String productName,
    required String price,
    required String likes,
  }) {
    return Container(
      margin: const EdgeInsets.only(right: 25),
      width: 190,
      height: 262,
      padding: const EdgeInsets.all(14), // Добавяне на padding
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color.fromARGB(255, 99, 98, 107),
            Color.fromARGB(255, 121, 118, 192),
            Color.fromARGB(255, 115, 86, 189)
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          stops: [0.0, 0.5, 1.0],
        ),
        borderRadius: BorderRadius.circular(28.0),
        border: Border.all(
          color: const Color.fromARGB(255, 142, 130, 171),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 0),
          Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(imageUrl),
                fit: BoxFit.fill,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            cupName,
            style: const TextStyle(
              color: Color(0xFFF7F7F7),
              fontSize: 13,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            productName,
            style: const TextStyle(
              color: Color(0xFFAFA6DA),
              fontSize: 12,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w400,
            ),
          ),
          const SizedBox(height: 2),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                price,
                style: const TextStyle(
                  color: Color(0xFFF7F7F7),
                  fontSize: 13,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(), // Добавя празно пространство между елементите
              Text(
                likes,
                style: const TextStyle(
                  color: Color(0xFFAFA6DA),
                  fontSize: 13,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
