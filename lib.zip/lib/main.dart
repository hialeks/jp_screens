import 'package:flutter/material.dart';
import 'package:jp_screens/src/features/overview/presentation/screens/screen_01.dart';

void main() {
  runApp(const MaterialApp(
    home: Screen01(),
  ));
}
